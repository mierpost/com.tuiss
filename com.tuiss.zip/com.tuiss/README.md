# Tuiss SmartView voor Homey Pro

Een Homey SDK v3-app die Tuiss SmartView gemotoriseerde raamdecoratie
rechtstreeks via Bluetooth Low Energy aanstuurt — vertaald vanuit de
Home Assistant-integratie **Tuiss2HA** van pink88
(https://github.com/pink88/Tuiss2HA).

## Status

Het protocol (echte UUID's en hex-commando's) is nu overgenomen uit
`const.py` en `hub.py` van Tuiss2HA. Dit is **niet getest tegen een
echte blind** — behandel het als een sterk startpunt, niet als
kant-en-klare, gegarandeerd werkende software. Test eerst voorzichtig
(bijv. eerst `stop`/`getBatteryStatus`, dan pas positie zetten).

## Structuur

- `lib/protocol.js` — alle GATT-UUID's, hex-commando's en conversiefuncties
  (positie ↔ hex, timestamp-commando, response-parsers), 1-op-1 vertaald
  vanuit `const.py` + de relevante delen van `hub.py`.
- `drivers/blind/driver.js` — koppel-logica: automatisch scannen én
  handmatig toevoegen op MAC-adres.
- `drivers/blind/pair/list_devices.html` — het koppelscherm zelf (scan-
  lijst + handmatig MAC-adresveld), aangeroepen door `driver.js`.
- `drivers/blind/device.js` — verbindingslogica (connect → keepalive +
  timestamp → commando → wachten op bevestiging → disconnect), open/dicht/
  positie/stop, batterijstatus, motorsnelheid, timers, limieten.

## Apparaat toevoegen

Het koppelscherm biedt twee opties, allebei op dezelfde pagina:

1. **Automatisch scannen** — zoekt 5 seconden naar BLE-advertenties met
   "Tuiss" of een modelnaam als "TS5200" erin. Werkt alleen als jouw
   motor dat daadwerkelijk uitzendt.
2. **Handmatig op MAC-adres** — voer het adres in (formaat
   `AA:BB:CC:DD:EE:FF`), te vinden op het label bij de accu/oplaadpoort
   van de motor, of op het label dat bij de blind is meegeleverd. Dit is
   de betrouwbaarste methode, want Tuiss2HA verbindt zelf ook altijd op
   MAC-adres, nooit op advertentienaam.

## Wat is geïmplementeerd

- Open/dicht/positie zetten, met wachten tot de blind de doelpositie bevestigt
- Stop
- Batterijstatus (goed/moet-opladen)
- Motorsnelheid (Standard/Comfort/Slow)
- Timers toevoegen/verwijderen/allemaal wissen (opgeslagen in het motorgeheugen zelf)
- Limieten configureren (open/dicht-grenzen handmatig instellen via stap/continu bewegen + heartbeat)

Deze methoden zitten in `device.js` maar zijn nog niet aan Homey Flow-kaarten
of de apparaat-UI gekoppeld (geen `flow.js`, geen instellingenscherm) —
je roept ze nu aan via de Homey app-console/CLI, of ik voeg Flow-kaarten
toe als je dat wilt.

## Wat nog ontbreekt t.o.v. Tuiss2HA

- **RSSI/signaalsterkte als sensor.**
- **Automatische reconnect-pogingen** zoals Tuiss2HA's
  `attempt_connection()` retry-logica — de huidige versie doet één
  verbindingspoging per commando en geeft een fout als die mislukt.
- **HA-timer-entiteiten** (namen/labels tonen in de UI) — de timers
  worden wel op de blind opgeslagen, maar Homey houdt zelf geen lijst bij.

## Belangrijke aandachtspunten

- **Bereik**: alleen zo ver als Bluetooth vanaf de Homey Pro zelf reikt.
  Tuiss2HA lost dit voor Home Assistant op met ESPHome BLE-proxies; dat
  concept bestaat niet standaard binnen Homey.
- **Eén verbinding tegelijk**: net als in Tuiss2HA verbindt de app per
  commando en sluit daarna weer af.
- **Batterij**: Tuiss geeft geen percentage, alleen goed/moet-opladen —
  vandaar `alarm_battery` in plaats van `measure_battery`.
- Zet in Homey Developer Tools de app in **debug-modus** en bekijk de
  console-logs bij je eerste testen; als een write faalt met een
  "characteristic not found"-fout, controleer dan of
  `discoverAllServicesAndCharacteristics()` daadwerkelijk alle services
  van jouw specifieke motor (RB23AGD-0.4/45) doorzoekt — sommige
  motorrevisies kunnen een net iets andere GATT-tabel hebben.

## Installeren op je Homey Pro

1. **Homey CLI installeren** (eenmalig, op je computer):
   ```
   npm install -g homey
   ```
2. **Inloggen bij je Athom-account**:
   ```
   homey login
   ```
3. **Ga naar de app-map** (deze zip uitgepakt) en installeer op je Homey Pro:
   ```
   cd com.tuiss
   homey app install
   ```
   De CLI vraagt welke Homey (als je er meerdere hebt) en logt live mee —
   laat dit venster openstaan, dat is ook je debug-console.
4. **Apparaat toevoegen**: open de Homey-app → Apparaat toevoegen →
   zoek "Tuiss" → je krijgt zowel een automatische scan als een veld om
   handmatig het MAC-adres in te voeren (zie "Apparaat toevoegen" hierboven).
5. **Testen zonder risico**: gebruik eerst `homey app run` in plaats van
   `install` tijdens het testen — dat draait de app tijdelijk vanaf je
   computer met live logs, zonder 'm permanent te installeren. Roep
   vanuit de Homey-app-console (Instellingen → Apps → Tuiss → ⋮ →
   Logs, of via `this.getBatteryStatus()` in een tijdelijke testregel in
   `onInit()`) eerst `getBatteryStatus()` aan om te controleren of de
   verbinding en UUID's kloppen, vóórdat je de blind laat bewegen.

Handige commando's tijdens ontwikkelen:
- `homey app validate` — controleert of `app.json` geldig is
- `homey app run` — draait de app live met console-logs, zonder installeren
- `homey app install` — installeert 'm blijvend op de Homey Pro
