'use strict';

const Homey = require('homey');
const {
  CHARACTERISTIC_WRITE_UUID,
  CHARACTERISTIC_NOTIFY_UUID,
  CONNECTION_MESSAGE,
  INITIALIZATION_MESSAGE,
  COMMANDS,
  buildSetPositionCommand,
  buildTimestampCommand,
  parseBatteryResponse,
  parsePositionResponse,
  parseMovementResponse,
  buildTimerCommand,
  buildTimerDeleteCommand,
  parseTimerIdResponse,
} = require('../../lib/protocol');

// How close (in Tuiss's 0-100 scale) the reported position needs to be to
// the desired position before we consider the move "done" and disconnect.
// Mirrors hub.py's set_position_callback() tolerance of 2.
const POSITION_TOLERANCE = 2;

// Mirrors hub.py's TIMEOUT_SECONDS
const MOVE_TIMEOUT_MS = 120 * 1000;

class TuissBlindDevice extends Homey.Device {

  async onInit() {
    this.log('Tuiss blind device initialised:', this.getName());
    this._desiredPosition = null;

    this.registerCapabilityListener('windowcoverings_state', this.onCapabilityState.bind(this));
    this.registerCapabilityListener('windowcoverings_set', this.onCapabilitySetPosition.bind(this));
  }

  // ------------------------------------------------------------------
  // Connection helpers
  // ------------------------------------------------------------------

  /**
   * Connects to the blind, runs `fn(peripheral, writeChar, notifyChar)`,
   * then always disconnects afterwards — mirrors Tuiss2HA's
   * connect-per-command pattern (hub.py's connect()/disconnect()), since
   * Homey (like most BLE stacks) only supports one active connection to
   * a peripheral at a time.
   */
  async _withConnection(fn) {
    const { address } = this.getData();
    const advertisement = await this.homey.ble.find(address);
    if (!advertisement) {
      throw new Error('Blind not found — is it in Bluetooth range?');
    }

    const peripheral = await advertisement.connect();
    try {
      await peripheral.discoverAllServicesAndCharacteristics();
      const writeChar = await peripheral.getCharacteristic(CHARACTERISTIC_WRITE_UUID);
      const notifyChar = await peripheral.getCharacteristic(CHARACTERISTIC_NOTIFY_UUID);

      // Mirrors hub.py's connect(): send keep-alive + timestamp right away
      await writeChar.write(Buffer.from(CONNECTION_MESSAGE, 'hex'));
      await writeChar.write(buildTimestampCommand());

      return await fn(peripheral, writeChar, notifyChar);
    } finally {
      try {
        await peripheral.disconnect();
      } catch (err) {
        this.log('Disconnect error (ignored):', err.message);
      }
    }
  }

  // ------------------------------------------------------------------
  // Capability handlers
  // ------------------------------------------------------------------

  /**
   * windowcoverings_state: 'up' | 'idle' | 'down'
   * 'up'/'down' map to fully open/closed; 'idle' sends STOP.
   */
  async onCapabilityState(value) {
    if (value === 'idle') {
      return this._sendStop();
    }
    const targetPercent = value === 'up' ? 100 : 0; // Homey: 100 = open
    return this._moveTo(targetPercent);
  }

  /**
   * windowcoverings_set: 0 (closed) - 1 (open), Homey convention.
   */
  async onCapabilitySetPosition(value) {
    const targetPercent = Math.round(value * 100);
    return this._moveTo(targetPercent);
  }

  // ------------------------------------------------------------------
  // Core operations (translated from hub.py)
  // ------------------------------------------------------------------

  /**
   * Moves the blind to a target position and waits (with timeout) for the
   * blind to report it has arrived, mirroring hub.py's set_position() +
   * set_position_callback().
   * @param {number} userPercent 0-100, Homey convention (100 = open)
   */
  async _moveTo(userPercent) {
    this._desiredPosition = 100 - userPercent; // convert to Tuiss scale, same as hub.py

    await this._withConnection((peripheral, writeChar, notifyChar) => new Promise(async (resolve, reject) => {
      let settled = false;
      const timeout = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.log('Timed out waiting for blind to reach target position');
        resolve();
      }, MOVE_TIMEOUT_MS);

      const onNotify = (data) => {
        const pos = parseMovementResponse(data);
        if (pos === null) return;
        this.setCapabilityValue('windowcoverings_set', 1 - (pos / 100)).catch(this.error);
        if (Math.abs(pos - this._desiredPosition) <= POSITION_TOLERANCE) {
          if (settled) return;
          settled = true;
          clearTimeout(timeout);
          resolve();
        }
      };

      try {
        await notifyChar.subscribeToNotifications(onNotify);
        await writeChar.write(buildSetPositionCommand(userPercent));
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    }));
  }

  /** Mirrors hub.py's stop() */
  async _sendStop() {
    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(Buffer.from(COMMANDS.STOP, 'hex'));
    });
  }

  /**
   * Reads the current position directly from the blind. Mirrors hub.py's
   * get_blind_position(). Useful for polling after manual/remote moves,
   * since Homey won't otherwise know the blind moved.
   */
  async getBlindPosition() {
    return this._withConnection((peripheral, writeChar, notifyChar) => new Promise(async (resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timed out waiting for position response')), 10000);

      const onNotify = (data) => {
        const pos = parsePositionResponse(data);
        if (pos === null) return;
        clearTimeout(timeout);
        this.setCapabilityValue('windowcoverings_set', 1 - (pos / 100)).catch(this.error);
        resolve(pos);
      };

      try {
        await notifyChar.subscribeToNotifications(onNotify);
        await writeChar.write(Buffer.from(INITIALIZATION_MESSAGE, 'hex'));
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    }));
  }

  /**
   * Reads battery status (binary good/low, Tuiss does not expose a real
   * percentage). Mirrors hub.py's get_battery_status()/battery_callback().
   */
  async getBatteryStatus() {
    return this._withConnection((peripheral, writeChar, notifyChar) => new Promise(async (resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timed out waiting for battery response')), 10000);

      const onNotify = (data) => {
        const status = parseBatteryResponse(data);
        if (status === null) return;
        clearTimeout(timeout);
        this.setCapabilityValue('alarm_battery', status === 'low').catch(this.error);
        resolve(status);
      };

      try {
        await notifyChar.subscribeToNotifications(onNotify);
        await writeChar.write(Buffer.from(COMMANDS.BATTERY_STATUS, 'hex'));
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    }));
  }

  /**
   * Sets the motor speed for supported models (TS5200/TS5101/TS5001/TS2600).
   * Mirrors hub.py's set_speed().
   * @param {'Standard'|'Comfort'|'Slow'} speed
   */
  async setBlindSpeed(speed) {
    const command = {
      Standard: COMMANDS.SPEED_STANDARD,
      Comfort: COMMANDS.SPEED_COMFORT,
      Slow: COMMANDS.SPEED_SLOW,
    }[speed];
    if (!command) throw new Error(`Unrecognised speed: ${speed}`);

    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(Buffer.from(command, 'hex'));
    });
  }

  // ------------------------------------------------------------------
  // Timers (mirrors hub.py's async_add_timer / async_delete_timer)
  // ------------------------------------------------------------------

  /**
   * Adds an on-blind timer (stored in the motor's own memory, survives
   * without Homey). The blind assigns its own timer ID, which this
   * function requests first.
   * @param {string[]} days e.g. ['mon','wed','fri']
   * @param {string} timeStr 'HH:MM'
   * @param {number} position 0-100
   * @returns {Promise<string>} the timer ID assigned by the blind
   */
  async addTimer(days, timeStr, position) {
    const timerId = await this._withConnection((peripheral, writeChar, notifyChar) => new Promise(async (resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timed out waiting for timer ID from blind')), 10000);

      const onNotify = (data) => {
        const id = parseTimerIdResponse(data);
        if (id === null) return;
        clearTimeout(timeout);
        resolve(id);
      };

      try {
        await notifyChar.subscribeToNotifications(onNotify);
        await writeChar.write(Buffer.from(COMMANDS.TIMER_REQUEST, 'hex'));
      } catch (err) {
        clearTimeout(timeout);
        reject(err);
      }
    }));

    if (Number(timerId) >= 17) {
      throw new Error('Maximum number of timers reached (16)');
    }

    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(buildTimerCommand(timerId, days, timeStr, position));
      await writeChar.write(Buffer.from(COMMANDS.BATTERY_STATUS, 'hex'));
    });

    return timerId;
  }

  /** @param {string} timerId */
  async deleteTimer(timerId) {
    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(Buffer.from(INITIALIZATION_MESSAGE, 'hex'));
      await writeChar.write(buildTimerDeleteCommand(timerId));
      await writeChar.write(Buffer.from(COMMANDS.BATTERY_STATUS, 'hex'));
    });
  }

  /** Deletes all timers and reactivates the blind. Mirrors hub.py's delete_all_timers(). */
  async deleteAllTimers() {
    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(Buffer.from(INITIALIZATION_MESSAGE, 'hex'));
      await writeChar.write(Buffer.from(COMMANDS.TIMER_RESET, 'hex'));
    });
    // Tuiss2HA reconnects after a reset and reactivates the blind
    await this._withConnection(async (peripheral, writeChar) => {
      await writeChar.write(Buffer.from(COMMANDS.BLIND_REACTIVATE, 'hex'));
    });
  }

  // ------------------------------------------------------------------
  // Limits configuration (mirrors hub.py's limits_* methods)
  // ------------------------------------------------------------------
  //
  // These let you manually jog the blind up/down to define its physical
  // open/closed endpoints. Call limitsInitialise() first, then
  // limitsStepUp()/limitsStepDown() (small nudges) or
  // limitsMoveUp()/limitsMoveDown() (continuous, call limitsStop() to
  // halt), then limitsSet() to save the current position as a limit.
  //
  // NOTE: unlike move/stop/battery, these intentionally keep the BLE
  // connection open across calls (you're actively jogging the blind),
  // so this device keeps its own peripheral/characteristic references
  // rather than using _withConnection per call. Call limitsFinish() when
  // done to disconnect cleanly.

  async limitsInitialise() {
    const { address } = this.getData();
    const advertisement = await this.homey.ble.find(address);
    if (!advertisement) throw new Error('Blind not found — is it in Bluetooth range?');

    this._limitsPeripheral = await advertisement.connect();
    await this._limitsPeripheral.discoverAllServicesAndCharacteristics();
    this._limitsWriteChar = await this._limitsPeripheral.getCharacteristic(CHARACTERISTIC_WRITE_UUID);

    await this._limitsWriteChar.write(Buffer.from(INITIALIZATION_MESSAGE, 'hex'));
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_INIT_2, 'hex'));
  }

  async limitsStepUp() {
    this._assertLimitsSession();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_STEP_UP, 'hex'));
  }

  async limitsStepDown() {
    this._assertLimitsSession();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_STEP_DOWN, 'hex'));
  }

  async limitsMoveUp() {
    this._assertLimitsSession();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_MOVE_UP, 'hex'));
    this._startLimitsHeartbeat(COMMANDS.LIMITS_MOVE_UP);
  }

  async limitsMoveDown() {
    this._assertLimitsSession();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_MOVE_DOWN, 'hex'));
    this._startLimitsHeartbeat(COMMANDS.LIMITS_MOVE_DOWN);
  }

  async limitsStop() {
    this._assertLimitsSession();
    this._stopLimitsHeartbeat();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.STOP, 'hex'));
  }

  async limitsSet() {
    this._assertLimitsSession();
    this._stopLimitsHeartbeat();
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.STOP, 'hex'));
    await this._limitsWriteChar.write(Buffer.from(COMMANDS.LIMITS_SET, 'hex'));
  }

  /** Ends a limits-configuration session and disconnects. */
  async limitsFinish() {
    this._stopLimitsHeartbeat();
    if (this._limitsPeripheral) {
      try {
        await this._limitsPeripheral.disconnect();
      } catch (err) {
        this.log('Limits disconnect error (ignored):', err.message);
      }
    }
    this._limitsPeripheral = null;
    this._limitsWriteChar = null;
  }

  _assertLimitsSession() {
    if (!this._limitsWriteChar) {
      throw new Error('Call limitsInitialise() before other limits_* methods');
    }
  }

  /** Sends CMD_HEARTBEAT + the move command every 2s while continuously jogging. */
  _startLimitsHeartbeat(moveCommandHex) {
    this._stopLimitsHeartbeat();
    this._limitsHeartbeatInterval = this.homey.setInterval(async () => {
      try {
        if (!this._limitsWriteChar) return;
        await this._limitsWriteChar.write(Buffer.from(COMMANDS.HEARTBEAT, 'hex'));
        await this._limitsWriteChar.write(Buffer.from(moveCommandHex, 'hex'));
      } catch (err) {
        this.log('Limits heartbeat failed:', err.message);
        this._stopLimitsHeartbeat();
      }
    }, 2000);
  }

  _stopLimitsHeartbeat() {
    if (this._limitsHeartbeatInterval) {
      this.homey.clearInterval(this._limitsHeartbeatInterval);
      this._limitsHeartbeatInterval = null;
    }
  }

}

module.exports = TuissBlindDevice;
