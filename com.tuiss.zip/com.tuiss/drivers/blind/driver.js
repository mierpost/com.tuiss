'use strict';

const Homey = require('homey');

const MAC_ADDRESS_REGEX = /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/;

class TuissBlindDriver extends Homey.Driver {

  async onInit() {
    this.log('Tuiss blind driver initialised');
  }

  /**
   * Custom pairing flow (see pair/list_devices.html): offers both an
   * automatic BLE scan and a manual MAC-address entry, since Tuiss
   * blinds don't reliably advertise a recognisable name and Tuiss2HA
   * itself always connects by known MAC address rather than discovery.
   */
  async onPair(session) {
    session.setHandler('list_devices', async () => {
      return this._discoverDevices();
    });

    session.setHandler('manual_add', async ({ mac, name }) => {
      const address = (mac || '').trim().toUpperCase();
      if (!MAC_ADDRESS_REGEX.test(address)) {
        throw new Error('Invalid MAC address format. Use AA:BB:CC:DD:EE:FF');
      }
      return {
        name: (name || '').trim() || `Tuiss blind (${address})`,
        data: {
          id: address,
          address,
        },
      };
    });
  }

  /**
   * Scans for nearby BLE advertisements and lists candidates whose
   * advertised name looks like a Tuiss blind ("Tuiss" or model prefixes
   * like TS5200). If your blind doesn't show up here, use the manual
   * MAC-address option instead — the address is printed on the tag
   * included with the blind, or near the battery/charge port on the
   * motor housing.
   */
  async _discoverDevices() {
    const advertisements = await this.homey.ble.discover([], 5000);

    const matches = advertisements.filter((adv) => {
      const name = adv.localName || '';
      return /tuiss|ts\d{3,4}/i.test(name);
    });

    return matches.map((adv) => ({
      name: adv.localName || `Tuiss blind (${adv.address})`,
      data: {
        id: adv.address,
        address: adv.address,
      },
    }));
  }

}

module.exports = TuissBlindDriver;
